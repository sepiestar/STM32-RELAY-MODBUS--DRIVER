#ifndef RS485_H
#define RS485_H
#include <stdint.h>
void RS485_SetTx(void);
void RS485_SetRx(void);
void RS485_StartRxDMA(void);
void RS485_Transmit_DMA(uint8_t *buf, uint16_t len);
extern uint8_t rs485_rx_buf[];
extern volatile uint16_t rs485_rx_buf_size;
#endif
