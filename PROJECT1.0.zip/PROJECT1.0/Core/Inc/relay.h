#ifndef RELAY_H
#define RELAY_H
#include <stdint.h>
#include <stdbool.h>
void Relay_Init(void);
void Relay_Set(uint8_t id, bool state);
bool Relay_Get(uint8_t id);
void Relay_SetBank(uint8_t bank, uint8_t mask);
#endif