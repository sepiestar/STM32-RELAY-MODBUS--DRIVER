#ifndef RELAY_TASK_H
#define RELAY_TASK_H
#include "cmsis_os2.h"
typedef enum { RELAY_CMD_SET, RELAY_CMD_SETBANK } RelayCmdType;
typedef struct {
  RelayCmdType type;
  uint8_t id;
  bool state;
  uint8_t bank;
  uint8_t mask;
} RelayCommand_t;
void RelayTask_Init(void);
#endif
