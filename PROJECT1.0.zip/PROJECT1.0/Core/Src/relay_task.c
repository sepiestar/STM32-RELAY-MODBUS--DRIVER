/*
 * relay_task.c
 *
 *  Created on: Oct 4, 2025
 *      Author: Brian Gabriel Mwangi
 */


#include "relay_task.h"
#include "relay.h"
#include "cmsis_os2.h"

osMessageQueueId_t relayQueue;

void RelayTask(void *arg){
  Relay_Init();
  RelayCommand_t cmd;
  for(;;){
    if(osMessageQueueGet(relayQueue, &cmd, NULL, osWaitForever) == osOK){
      if(cmd.type == RELAY_CMD_SET) Relay_Set(cmd.id, cmd.state);
      else if(cmd.type == RELAY_CMD_SETBANK) Relay_SetBank(cmd.bank, cmd.mask);
    }
  }
}

void RelayTask_Init(void){
  relayQueue = osMessageQueueNew(16, sizeof(RelayCommand_t), NULL);
  osThreadNew(RelayTask, NULL, NULL);
}
