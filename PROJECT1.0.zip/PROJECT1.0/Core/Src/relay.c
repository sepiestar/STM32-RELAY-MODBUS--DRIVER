#include "relay.h"
#include "main.h"

static GPIO_TypeDef* relay_ports[32] = {
  GPIOA, GPIOA, GPIOA, GPIOA, GPIOA, GPIOA, GPIOA, GPIOA,
  GPIOB, GPIOB, GPIOB, GPIOB, GPIOB, GPIOB, GPIOB, GPIOB,
  GPIOC, GPIOC, GPIOC, GPIOC, GPIOC, GPIOC, GPIOC, GPIOC,
  GPIOD, GPIOD, GPIOD, GPIOD, GPIOD, GPIOD, GPIOD, GPIOD
};

static const uint16_t relay_pins[32] = {
  GPIO_PIN_0, GPIO_PIN_3, GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_11, GPIO_PIN_12, GPIO_PIN_15,
  GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_10, GPIO_PIN_14, GPIO_PIN_15, GPIO_PIN_5, GPIO_PIN_6,
  GPIO_PIN_0, GPIO_PIN_2, GPIO_PIN_3, GPIO_PIN_6, GPIO_PIN_7, GPIO_PIN_8, GPIO_PIN_9, GPIO_PIN_10,
  GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3, GPIO_PIN_4, GPIO_PIN_5, GPIO_PIN_6, GPIO_PIN_7
};

void Relay_Init(void){
  for(int i=0;i<32;i++){
    HAL_GPIO_WritePin(relay_ports[i], relay_pins[i], GPIO_PIN_RESET);
  }
}
void Relay_Set(uint8_t id, bool state){
  if(id >= 32) return;
  HAL_GPIO_WritePin(relay_ports[id], relay_pins[id], state ? GPIO_PIN_SET : GPIO_PIN_RESET);
}
bool Relay_Get(uint8_t id){
  if(id >= 32) return false;
  return (HAL_GPIO_ReadPin(relay_ports[id], relay_pins[id]) == GPIO_PIN_SET);
}
void Relay_SetBank(uint8_t bank, uint8_t mask){
  uint8_t base = bank * 8;
  for(uint8_t i=0; i<8; i++){
    Relay_Set(base + i, (mask >> i) & 0x01);
  }
}
