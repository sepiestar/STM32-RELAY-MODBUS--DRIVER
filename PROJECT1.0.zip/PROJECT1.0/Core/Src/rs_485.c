#include "rs485.h"
#include "main.h"
#include "usart.h"
#include "cmsis_os2.h"

#define DE_PORT RS485_DE_GPIO_Port
#define DE_PIN  RS485_DE_Pin

uint8_t rs485_rx_buf[256];
volatile uint16_t rs485_rx_buf_size = sizeof(rs485_rx_buf);

void RS485_SetTx(void){ HAL_GPIO_WritePin(DE_PORT, DE_PIN, GPIO_PIN_SET); }
void RS485_SetRx(void){ HAL_GPIO_WritePin(DE_PORT, DE_PIN, GPIO_PIN_RESET); }

void RS485_StartRxDMA(void){
  HAL_UART_Receive_DMA(&huart1, rs485_rx_buf, rs485_rx_buf_size);
  __HAL_UART_ENABLE_IT(&huart1, UART_IT_IDLE); // enable IDLE detection
}

void RS485_Transmit_DMA(uint8_t *buf, uint16_t len){
  RS485_SetTx();
  HAL_UART_Transmit_DMA(&huart1, buf, len);
}
